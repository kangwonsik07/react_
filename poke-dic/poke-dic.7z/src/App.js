import React, { useState, useRef, useCallback } from 'react'
import PokeTemplate from './pokemon/PokeTemplate'
import PokeList from './pokemon/PokeList'
import PokeInsert from './pokemon/PokeInsert'

function App() {
   const [pokes, setPokes] = useState([
      {
         id: 1,
         text: '이상해씨',
         img: './images/이상해씨.png',
      },
      {
         id: 2,
         text: '파이리',
         img: './images/파이리.png',
      },
      {
         id: 3,
         text: '꼬부기',
         img: './images/꼬부기.png',
      },
   ])

   const [graydb, setGrayDb] = useState({})

   const nextId = useRef(4)

   const onDoubleClick = (id) => {
      setGrayDb((prevStatus) => ({
         ...prevStatus,
         [id]: !prevStatus[id],
      }))
      console.log(graydb)

      console.log([id])
   }

   const onInsert = useCallback(
      (text) => {
         const poke = {
            id: nextId.current, // ref의 값을 가져온다
            text, //text: text,
            img: '/images/' + text + '.png',
         }

         setPokes(pokes.concat(poke))
         nextId.current += 1 // nextId를 1씩 더하기
      },
      [pokes]
   )
   const onRemove = useCallback(
      (id) => {
         const removedPokes = pokes.filter((poke) => poke.id !== id)
         setPokes(removedPokes)
      },
      [pokes]
   )

   return (
      <PokeTemplate>
         <PokeInsert onInsert={onInsert} />
         <PokeList pokes={pokes} graydb={graydb} onRemove={onRemove} onDoubleClick={onDoubleClick} />
      </PokeTemplate>
   )
}

export default App
