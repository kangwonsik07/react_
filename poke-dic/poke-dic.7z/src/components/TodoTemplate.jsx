import './css/TodoTemplate.css'

function TodoTemplate({ children }) {
   // children = <TodoInsert/>,<TodoList/>컴포넌트
   return (
      <div className="TodoTemplate">
         <div className="app-title">포켓몬 도감</div>
         <div className="content">{children}</div>
      </div>
   )
}

export default TodoTemplate
